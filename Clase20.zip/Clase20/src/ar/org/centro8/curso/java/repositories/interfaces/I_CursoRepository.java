package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import java.util.List;

public interface I_CursoRepository {
    void save(Curso curso);
    void remove(Curso curso);
    void update(Curso curso);
    Curso getById(int id);
    List<Curso>getAll();
    List<Curso>getLikeTitulo(String titulo);
    List<Curso>getLikeTituloProfesor(String titulo, String profesor);
    List<Curso>getByDia(Dia dia);
}