package ar.org.centro8.curso.java.repositories.interfaces;

public interface I_AlumnoRepository {

}