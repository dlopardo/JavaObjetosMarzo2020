package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepositories {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        
        Curso curso=new Curso("HTML", "Salas", Dia.VIERNES, Turno.MAÑANA);        
        cr.save(curso);
        cr.remove(cr.getById(10));
        System.out.println(curso);
       
        curso=cr.getById(7);
        curso.setTurno(Turno.TARDE);
        cr.update(curso);
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        cr.getLikeTitulo("ja").forEach(System.out::println);
        
    }
}