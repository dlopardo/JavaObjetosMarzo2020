package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class AlumnoRepository implements I_AlumnoRepository{
    private Connection conn;

    public AlumnoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Alumno alumno) {
        if(alumno==null) return;
    }

    @Override
    public void remove(Alumno alumno) {
        if(alumno==null) return;
    }

    @Override
    public void update(Alumno alumno) {
        if(alumno==null) return;
    }

    @Override
    public List<Alumno> getAll() {
        List<Alumno>list=new ArrayList();
        
        return list;
    }

}