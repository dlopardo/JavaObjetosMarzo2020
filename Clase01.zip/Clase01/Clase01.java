/*
	Curso: Programación Orientada a Objetos (Java).
	Duración:	150 hs.
	Días:	Lunes, Miércoles, Viernes 19:00 a 22:20 hs.
	Profe: Carlos Ríos	lawlercarlospatricio@gmail.com
	
	Software:	JDK 	Java Development Kit
	
	LTS Long Term Support	8 años
	
	Version			Liberado				Caduca
	JDK 8 LTS		Marzo 2014				Marzo 2022
	JDK 9 			Octubre 2017			Marzo 2018
	JDK 10			Marzo 2018				Octubre 2018
	JDK 11 LTS		Octubre 2018			Octubre 2026
	JDK 12			Marzo 2019				Octubre 2019
	JDK 13			Octubre 2019			Marzo 2020
	JDK 14			Marzo 2020				Octubre 2020
	JDK 15			Octubre 2020			Marzo 2021
	JDK 16			Marzo 2021				Octubre 2021
	JDK 17 LTS		Octubre 2021			Octubre 2029
	
	IDE:	Eclipse - Netbeans - Spring Tools Suite
	
	
*/

/**
 * Clase principal de proyecto.
 * @author carlos
 */
public class Clase01{
	
	 /**
     * Punto de entrada del proyecto
     * @param args argumentos que ingresan por consola
     */
	public static void main(String[] args){
		//Punto de entrada al proyecto.
		System.out.println("Hola Mundo!");
		System.out.println(System.getProperty("java.version"));
		
		// linea de comentarios
		
		/* Bloque de comentarios */
		
		/** 
		 * Bloque de comentarios JavaDOC 
		 * Colocar este comentarios delante de la declaración de clases.
		 * Este comentario puede salir del binario o ejecutable.
		 */
		 
		// String[] args
		System.out.println("Longitud args: "+args.length);
		for(int a=0;a<args.length;a++){
			System.out.println(args[a]);
		}
		
		
		// Tipo de datos
		
		// Lenguaje tipado fuerte.
		
		
		// Tipo de datos enteros			1 byte
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		/*
			1
			--------
		*/ 
		
		// Tipo de datos byte signed		1 byte
		byte by=-100;
		by=120;
		System.out.println(by);		
		
		/*
		 * 
		 * 			tinyint
		 * 
		 * 		|-------|-------|
		 *    -128      0 	   127
		 * 
		 * 
		 * 
		 * 			tinyint unsigned
		 * 			byteU
		 * 
		 * 		|---------------|
		 * 		0			   255
		 * 
		 */ 
		
		// Tipo de datos short			2 byte
		short sh=32000;
		System.out.println(sh);
		
		// Tipo de datos int			4 bytes
		int in=200000;
		System.out.println(in);
		
		
		
	}
}



























