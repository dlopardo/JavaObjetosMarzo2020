package clase03;

//Declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
      
    //Métodos constructores
    
    /**
     * Este método fue deprecado por Carlos Ríos el 29/03/2021
     * por resultar inseguro.
     * usar en su reemplazo Auto(String marca, String modelo, String color).
     * @deprecated
     */
    @Deprecated
    Auto(){} //constructor vacio
    
    Auto(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    //métodos
    void acelerar(){                                    //acelerar
        velocidad+=10;
        if(velocidad>100) velocidad=100;
    }
    
    //métodos sobrecargados
    void acelerar(int kilometros){                      //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    void acelerar(int r, int x){                        //acelerarIntInt
        
    }
    
    void acelerar(int r, String x){                     //acelerarIntString
        
    }
    
    //  int acelerar(){}    //error
    
    void frenar(){
        velocidad-=10;
    }
    
}//end class