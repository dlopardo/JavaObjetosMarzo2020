package clase03;

public class Clase03 {

    public static void main(String[] args) {
        //Clase 03
        
        String texto="Esto es una cadena de texto!";
        System.out.println(texto);
        System.out.println(texto.toString());

        for(int a=0;a<texto.length();a++){
            System.out.print(texto.charAt(a));
        }
        System.out.println();

        //Imprimir texto en mayusculas
        for(int a=0;a<texto.length();a++){ 
            char ch=texto.charAt(a);
            if(ch>=95 && ch<=122) ch-=32;
            System.out.print(ch);
        }
        System.out.println();
        
        //operador ternario ?
        for(int a=0;a<texto.length();a++){ 
            char ch=texto.charAt(a);
            System.out.print((ch>=95 && ch<=122)?ch-=32:ch);
        }
        System.out.println();
        
        //Imprimir texto en minusculas
        for(int a=0;a<texto.length();a++){ 
            char ch=texto.charAt(a);
            System.out.print((ch>=65 && ch<=90)?ch+=32:ch);
        }
        System.out.println();
        
        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());
        
        
        // Paradigma de la programación orienta a Objetos.
        
        /*
        Clases: Una clase es todo lo que se encuentra en forma sustantiva en el
            mundo real. Se escribe como sustantivo en singular.
        Ejemplo: Empleado, Silla, Factura
        
        Clases en Java: Las clases son objetos de la clase java.lang.Class
        
        
        Atributos:  Los atributos describen a la clases. La clase declara 
            atributos y los objetos le completan el estado. 
            Los atributos tienen un tipo de datos definido.
            Son variables contenidas dentro de una clase (Tienen un proceso de inicialización)
        
        Atributos en java: son objetos de la clase java.lang.reflect.Field
        
        Los métodos: son acciones contenidas dentro de una clase. Se declaran como verbos
        
        Métodos en Java: son objetos de la clase java.lang.reflect.Method
        
        
        Que son los objetos: son instancias de la clase, tienen estado propio.
        
        Los Parametros de entrada en Java: son objetos de la clase java.lang.reflect.Parameter
        
        Constructores en Java: los constructores son objetos de la clase java.lang.reflect.Constructor
        
        */
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();
        auto1.marca="Fiat";
        auto1.modelo="Doblo";
        auto1.color="Rojo";
        auto1.acelerar();               // 10
        auto1.acelerar();               // 20
        auto1.acelerar();               // 30
        auto1.frenar();                 // 20
        auto1.acelerar(13);             // 33
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        
        String x;
        int nro;
        //Error no se puede imprimir una variable no inicializada.
        //System.out.println(x);
        //System.out.println(nro);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Fiesta";
        auto2.color="Rojo";
        
        for(int a=0;a<=60;a++) auto2.acelerar();
        
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Citroen", "C4", "Rojo");
        
        
        System.out.println("-- auto4 --");
        Auto auto4=new Auto();
        
        
    }

}
