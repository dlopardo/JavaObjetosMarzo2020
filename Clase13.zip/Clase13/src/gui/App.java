package gui;

public class App {
    public static void main(String[] args) {
        /*
        AWT: Abstract Windows Type.
        
        Swing (JFrame): 
        
        JavaFX: 
        
        XWT
        
        */
    }
}