package collections;

import java.util.Objects;

public class Auto implements Comparable<Auto>{
    private String marca;
    private String modelo;
    private String color;

    public Auto() {
    }

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", modelo=" + modelo + ", color=" + color + '}';
    }

    @Override
    public int hashCode() {
        return toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        return hashCode()==obj.hashCode();
    }

    @Override
    public int compareTo(Auto para) {
       String thisAuto=this.getColor()+","+this.getMarca()+","+this.getModelo();
       String paraAuto=para.getColor()+","+para.getMarca()+","+para.getModelo();
       return thisAuto.compareTo(paraAuto);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}