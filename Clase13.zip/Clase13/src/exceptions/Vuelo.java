package exceptions;

public class Vuelo {
    private String nombre;
    private int cantidadPasajesDisponibles;

    public Vuelo(String nombre, int cantidadPasajesDisponibles) {
        this.nombre = nombre;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
    }
    
    public synchronized void venderPasajes(int cantidadPasajesPedida) 
                                                                throws NoHayMasPasajesException{
        if(cantidadPasajesDisponibles<cantidadPasajesPedida) 
            throw 
                new NoHayMasPasajesException(
                        nombre, 
                        cantidadPasajesDisponibles, 
                        cantidadPasajesPedida);
        cantidadPasajesDisponibles-=cantidadPasajesPedida;
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", cantidadPasajesDisponibles=" + cantidadPasajesDisponibles + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadPasajesDisponibles() {
        return cantidadPasajesDisponibles;
    }
 
}