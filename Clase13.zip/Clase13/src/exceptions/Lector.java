package exceptions;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements Closeable {

    private FileReader in;

    public Lector(String file) throws FileNotFoundException {
        this.in = new FileReader(new File(file));
    }

    public int leer() throws IOException {
        //if(true)throw new IOException();
        return in.read();
    }

    @Override
    public void close() throws IOException {
        in.close();
        System.out.println("Se cerro la conexión");
    }

}
