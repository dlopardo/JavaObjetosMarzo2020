package exceptions;

public class NoHayMasPasajesException extends Exception {
    private String nombreVuelo;
    private int cantidadPasajesDisponibles;
    private int cantidadPasajesPedida;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesDisponibles, int cantidadPasajesPedida) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
        this.cantidadPasajesPedida = cantidadPasajesPedida;
    }

    @Override
    public String toString() {
        return getMessage();
    }

    @Override
    public String getMessage() {
        return "El vuelo "+nombreVuelo+", no tiene "+cantidadPasajesPedida
                +" pasajes, solo hay "+cantidadPasajesDisponibles+" pasajes disponibles.";
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesDisponibles() {
        return cantidadPasajesDisponibles;
    }

    public int getCantidadPasajesPedida() {
        return cantidadPasajesPedida;
    }

}