package stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class App {
    
    private static List<Persona>lista=new ArrayList();
    
    public static void main(String[] args) {
        cargar();
        
        //API Stream Java 9 o sup.
        
        //select * from personas where nombre='cristian':
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("cristian"))
                .forEach(System.out::println);
        
        //select * from personas where nombre like '%cri%';
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("cri"))
                .forEach(System.out::println);
        
        //select * from personas where nombre like '%cri%' 
        //              and apellido like '%ez%';
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("cri")
                        && p.getApellido().toLowerCase().contains("ez"))
                .forEach(System.out::println);
        
        //select * from personas where edad >= 35;
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getEdad()>=35)
                .forEach(System.out::println);
        
        //select * from personas where edad between 30 and 40;
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
                .forEach(System.out::println);
        
        //select * from personas where edad not between 30 and 40;
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getEdad()<30 || p.getEdad()>40)
                .forEach(System.out::println);
        
        
        //select * from personas order by edad;
        System.out.println("**********************************************");
        lista
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad))
                .forEach(System.out::println);
        
        
        //select * from personas order by edad desc;
        System.out.println("**********************************************");
        lista
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed())
                .forEach(System.out::println);
        
        //select * from personas where nombre like '%a' order by edad desc;
        System.out.println("**********************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed())
                .forEach(System.out::println);
        
        //select * from personas order by apellido,nombre,edad desc;
        System.out.println("**********************************************");
        lista
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed())
                .sorted(
                        Comparator
                            .comparing(Persona::getApellido)
                            .thenComparing(Persona::getNombre)
                )
                .forEach(System.out::println);
                
        //select max(edad) from personas;
        System.out.println("**********************************************");
        int edadMax=lista
                .stream()
                .max(Comparator.comparingInt(Persona::getEdad))
                .get()
                .getEdad();
                
        System.out.println("La edad max es: "+edadMax);        
        
        //select * from personas where edad=(select max(edad) from personas);
        lista
                .stream()
                .filter(p->p.getEdad()==edadMax)
                .forEach(System.out::println);
        
        
        
    }
    
    private static void cargar(){
        lista.add(new Persona("Laura","Salas",26));
        lista.add(new Persona("Cristian","Molina",36));
        lista.add(new Persona("Debora","Vargas",23));
        lista.add(new Persona("Miguel","Vasquez",38));
        lista.add(new Persona("Lorena","Torres",32));
        lista.add(new Persona("Marta","Montes",52));
        lista.add(new Persona("Cristiano","Montes",37));
        lista.add(new Persona("Pedro","Miguel",42));
        lista.add(new Persona("Cristian","Perez",36));
        lista.add(new Persona("Cristina","Lopez",39));
        lista.add(new Persona("Cristina","Lopez",18));
        lista.add(new Persona("Cristina","Lopez",25));
        lista.add(new Persona("Cristina","Lopez",49));
        lista.add(new Persona("Gabriel","Lopez",52));
    }
    
}