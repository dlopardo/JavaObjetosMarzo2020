package ar.org.centro8.curso.java.clase30;

public class HiloR implements Runnable{
    private String nombre;
    private int time=1000;

    public HiloR(String nombre) {
        this.nombre = nombre;
    }
    
    public HiloR(String nombre,int time) {
        this.nombre = nombre;
        this.time = time;
    }
    
    @Override
    public void run() {
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try { Thread.sleep(time); } catch(Exception e){}
        }
    }
    
}
