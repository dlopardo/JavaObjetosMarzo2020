public class Clase36 {
    class Clase37{}
}
class Clase38{


}
interface Clase40{}
interface Clase41{}
enum Clase42{}
enum Clase43{}

interface I_Cabeza{}
class Mamifero{
    I_Cabeza cabeza;

}

class CabezaPerro implements I_Cabeza{}


class Humano{
    private String nombre;
    private void saludar(){}
    private class CabezaHumano implements I_Cabeza {
        CabezaHumano(){
            nombre="Juan";
            saludar();
        }
    }
    
}


class Auto{
    private String marca;

    private void viajar(){
        class Motor{
            private int peso;
        }
        Motor motor=new Motor();
        motor.peso=300;
    }
    
}

