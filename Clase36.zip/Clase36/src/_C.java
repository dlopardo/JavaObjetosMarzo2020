public class _C {
    private static int $;
    private static String a_b;
    public static void main(String[] main) 
    {
        System.out.print($);
        $++;
        //System.out.println($);
        System.out.print(a_b);
    } 
}