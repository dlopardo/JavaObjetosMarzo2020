package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.ClienteEmpresa;
import ar.org.centro8.curso.java.entities.ClientePersona;
import ar.org.centro8.curso.java.entities.Cuenta;
import java.util.ArrayList;

public class TestRelaciones {
    public static void main(String[] args) {
        
        //Objetos Mocks
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(20000);
        cuenta1.debitar(15000);
        System.out.println(cuenta1);
        
        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(1, "Juan", 30, new Cuenta(2,"arg$"));
        clientePersona1.comprar();
        clientePersona1
                .getCuenta()
                .depositar(50000);
        
        Cuenta cuentaCliente1=clientePersona1.getCuenta();
        cuentaCliente1.depositar(20000);
        
        System.out.println("-- clientePersona2 --");
        ClientePersona clientePersona2=new ClientePersona(
                2, "Lorena",30,clientePersona1.getCuenta());
        clientePersona2.getCuenta().debitar(10000);
        clientePersona2.comprar();
        
        System.out.println(clientePersona1);
        System.out.println(clientePersona2);
        
        
        System.out.println("-- cllienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1, "Todo limpio srl", "Medrano 162");
        
        ArrayList<Cuenta>list=clienteEmpresa1.getCuentas();
        
        list.add(new Cuenta(10,"arg$"));            // 0
        list.add(new Cuenta(11,"reales"));          // 1
        list.add(new Cuenta(12,"U$S"));             // 2
        
        list.get(0).depositar(250000);
        list.get(0).depositar(30000);
        list.get(0).debitar(12000);
        
        list.get(1).depositar(24000);
        
        list.get(2).depositar(5400);

        System.out.println(clienteEmpresa1);
        for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        
    }
}