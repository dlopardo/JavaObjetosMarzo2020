package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.entities.Cuenta;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Persona;
import ar.org.centro8.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(20000);
        cuenta1.debitar(15000);
        System.out.println(cuenta1);
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Medrano", 162, "1", "1");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgrano", 48, null, null, "Moron");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Juan", 30, dir2);
        persona1.saludar();
        System.out.println(persona1.toString());
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Javier", 32, persona1.getDireccion());
        persona1.saludar();
        System.out.println(persona2.toString());
        */
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(1, 300000, "Leonardo", 40, dir1);
        vendedor1.saludar();
        System.out.println(vendedor1);
        
        System.out.println(vendedor1.getClass());
        System.out.println(vendedor1.getClass().getName());
        System.out.println(vendedor1.getClass().getSimpleName());
        System.out.println(vendedor1.getClass().getSuperclass().getName());
        System.out.println(vendedor1
                .getClass()
                .getSuperclass()
                .getSuperclass()
                .getName());
        System.out.println(vendedor1
                .getClass()
                .getSuperclass()
                .getSuperclass()
                .getSuperclass());
        System.out.println("Hola".getClass().getSuperclass().getName());
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1, cuenta1, "Laura", 50, dir2);
        cliente1.getCuenta().depositar(20000);
        cliente1.saludar();
        System.out.println(cliente1);
        
        System.out.println("****************************************************");
        
        //Polimorfismo - Poliformismo
        Persona p1= new Vendedor(2, 888880, "Jeremias", 40, dir2);
        Persona p2= new Cliente(2, cuenta1, "Gabriel", 50, dir1);
        
        p1.saludar();
        p2.saludar();
        
        Vendedor v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        
        
        
        /*
        pendientes
        
        interfaces
        
        static
        
        */
        
        
        
        
        
        
    }
}