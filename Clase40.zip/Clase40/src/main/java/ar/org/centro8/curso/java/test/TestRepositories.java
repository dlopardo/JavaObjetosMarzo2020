package ar.org.centro8.curso.java.test;

//import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.jpa.AlumnoRepository;
import ar.org.centro8.curso.java.repositories.jpa.CursoRepository;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
//import ar.org.centro8.curso.java.repositories.jdbc.AlumnoRepository;
//import ar.org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepositories {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        I_CursoRepository cr=new CursoRepository(emf);
        
        Curso curso=new Curso("Cafe Artesanal", "Díaz", Dia.VIERNES.toString(), Turno.TARDE.toString());        
        cr.save(curso);
        
        System.out.println(curso);
       
        cr.remove(cr.getById(50));
        
        curso=cr.getById(53);
        curso.setDia(Dia.JUEVES.toString());
        cr.update(curso);
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        cr.getLikeTitulo("ja").forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(emf);
        
        Alumno alumno=new Alumno("Melina", "Lezcano", 26, cr.getById(1));
        
        ar.save(alumno);
        System.out.println(alumno);
        
        ar.remove(ar.getById(5));
        
        alumno=ar.getById(10);
        alumno.setApellido("Morales");
        ar.update(alumno);
        
        System.out.println("****************************************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        ar.getLikeApellido("ri").forEach(System.out::println);
        
        
        emf.close();
    }
}