package ar.org.centro8.curso.java.repositories.jpa;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class CursoRepository implements I_CursoRepository {

    private EntityManagerFactory emf;

    public CursoRepository(EntityManagerFactory emf) {
        this.emf = emf;
    }

    @Override
    public void save(Curso curso) {
        if(curso==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(curso);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println(e);
        }
        em.close();
    }

    @Override
    public void remove(Curso curso) {
        if(curso==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.remove(curso);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println(e);
        }
        em.close();    
    }

    @Override
    public void update(Curso curso) {
        if(curso==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(curso);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println(e);
        }
        em.close();    
    }

    @Override
    public List<Curso> getAll() {
        EntityManager em=emf.createEntityManager();
        List<Curso>list=(List<Curso>)em
                .createNamedQuery("Curso.findAll")
                .getResultList();
        em.close();
        return list;
    }
    
}
