package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_CursoRepository {
    void save(Curso curso);             // insert into cursos
    void remove(Curso curso);           // delete from cursos
    void update(Curso curso);           // update cursos
    List<Curso>getAll();                // select * from cursos
    default Curso getById(int id){
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Curso());
    }      
    default List<Curso>getLikeTitulo(String titulo){ 
        // select * from cursos where titulo like '%titulo%';
        if(titulo==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(c->c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Curso>getLikeTituloAndProfesor(String titulo, String profesor){
        if(titulo==null || profesor==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(c->c.getTitulo().toLowerCase().contains(titulo.toLowerCase())
                        && c.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Curso>getByDia(Dia dia){
        if(dia==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(c->c.getDia().equals(dia.toString()))
                .collect(Collectors.toList());
    }
}