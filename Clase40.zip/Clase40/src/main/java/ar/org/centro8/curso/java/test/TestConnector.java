package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestConnector {

    public static void main(String[] args) throws Exception {
        
        time();
        System.out.println("-- Inicia Entity Manager Factory");
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        time();
        System.out.println("-- Crea EntityManager");
        EntityManager em=emf.createEntityManager();
        time();
        
        Curso curso=new Curso("Java", "Lorenzo", "LUNES", "NOCHE");
        
        em.getTransaction().begin();
        em.persist(curso);
        em.getTransaction().commit();
        System.out.println(curso);
   
        em
                .createNamedQuery("Curso.findAll")
                .getResultList()
                .forEach(System.out::println);
        
        em
                .createNamedQuery("Alumno.findAll")
                .getResultList()
                .forEach(System.out::println);
        
        Query query=em.createNamedQuery("Curso.findByTitulo");
        query.setParameter("titulo", "cocina");
        query.getResultList().forEach(System.out::println);
        
        query=em.createNamedQuery("Alumno.findLikeApellido");
        query.setParameter("apellido", "%me%");
        query.getResultList().forEach(System.out::println);
        
        
//        query=em.createNamedQuery("Alumno.findById");
//        query.setParameter("id", 9);
//        Alumno alumno=(Alumno)query.getSingleResult();
//        System.out.println(alumno);
//        
//        em.getTransaction().begin();
//        em.remove(alumno);
//        em.getTransaction().commit();
        
        
        
        time();
        System.out.println("-- Cierra EntityManager");
        em.close();
        time();
        System.out.println("-- Cierra EntityManagerFactory");
        emf.close();
        time();
    }
    
    private static void time(){
        System.out.println("\033[34m****************************************************");
        System.out.println("\033[34m"+LocalTime.now());
        System.out.println("\033[34m****************************************************");
    }
    
}
