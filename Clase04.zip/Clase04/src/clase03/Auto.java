package clase03;

//Declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
      
    //Métodos constructores
    
    /**
     * Este método fue deprecado por Carlos Ríos el 29/03/2021
     * por resultar inseguro.
     * usar en su reemplazo Auto(String marca, String modelo, String color).
     * @deprecated
     */
    @Deprecated
    public Auto(){} //constructor vacio
    
    Auto(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    //métodos
    void acelerar(){                                    //acelerar
        acelerar(10);
    }
    
    //métodos sobrecargados
    void acelerar(int kilometros){                      //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    void acelerar(int kilometros, boolean tieneNitro){
        if(tieneNitro){
            acelerar(kilometros*2);
        }else{
            acelerar(kilometros);
        }
    }
    
    void acelerar(int r, int x){                        //acelerarIntInt
        
    }
    
    void acelerar(int r, String x){                     //acelerarIntString
        
    }
    
    //  int acelerar(){}    //error
    
    void frenar(){
        velocidad-=10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    int getVelocidad(){
        return velocidad;
    }
    
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
    public String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
}//end class