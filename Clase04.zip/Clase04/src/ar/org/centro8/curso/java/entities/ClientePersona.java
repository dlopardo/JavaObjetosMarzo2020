package ar.org.centro8.curso.java.entities;

public class ClientePersona {
    int nro;
    String nombre;
    int edad;
    Cuenta cuenta;
    
    
}