package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        
        //Objetos Mocks
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(20000);
        cuenta1.debitar(15000);
        System.out.println(cuenta1);
        
        
    }
}