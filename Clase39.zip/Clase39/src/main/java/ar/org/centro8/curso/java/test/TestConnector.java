package ar.org.centro8.curso.java.test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestConnector {

    public static void main(String[] args) throws Exception {
        time();
        System.out.println("-- Inicia Entity Manager Factory");
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        time();
        System.out.println("-- Crea EntityManager");
        EntityManager em=emf.createEntityManager();
        time();
        
        time();
        System.out.println("-- Cierra EntityManager");
        em.close();
        time();
        System.out.println("-- Cierra EntityManagerFactory");
        emf.close();
        time();
    }
    
    private static void time(){
        System.out.println("\033[34m****************************************************");
        System.out.println("\033[34m"+LocalTime.now());
        System.out.println("\033[34m****************************************************");
    }
    
}
