package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class CursoRepository implements I_CursoRepository{
    
    private Connection conn;

    public CursoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Curso curso) {
        if(curso==null) return;
        
        //No hacer Esto!!!!!!
        //String query="insert into cursos (titulo,profesor,dia,turno) values ("
        //        + "'"+curso.getTitulo()+"','"+curso.getProfesor()+"',"
        //        + "'"+curso.getDia()+"','"+curso.getTurno()+"')";
        /*
        insert into cursos (titulo,profesor,dia,turno) 
            values ('xxx','x','LUNES','TARDE'); delete from alumnos; -- ','+LUNES+','+TARDE+')
        */
           
        //No hacer Esto!!!!!!
        //try (Statement st=conn.createStatement()){
        //    st.execute(query);
        //} catch (Exception e) {
        //    System.out.println(e);
        //}
        
        try(PreparedStatement ps=conn.prepareStatement(
                "insert into cursos (titulo,profesor,dia,turno) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, curso.getTitulo());
            ps.setString(2, curso.getProfesor());
            ps.setString(3, curso.getDia()+"");
            ps.setString(4, curso.getTurno()+"");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Curso curso) {
        if(curso==null) return;
    }

    @Override
    public void update(Curso curso) {
        if(curso==null) return;
    }

    @Override
    public List<Curso> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}