package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.AlumnoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepositories {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        
        Curso curso=new Curso("Cafe Artesanal", "Díaz", Dia.VIERNES, Turno.TARDE);        
        cr.save(curso);
        
        System.out.println(curso);
       
        cr.remove(cr.getById(50));
        
        curso=cr.getById(53);
        curso.setDia(Dia.JUEVES);
        cr.update(curso);
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        cr.getLikeTitulo("ja").forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        
        Alumno alumno=new Alumno("Melina", "Lezcano", 26, 1);
        
        ar.save(alumno);
        System.out.println(alumno);
        
        System.out.println("****************************************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        ar.getLikeApellido("ri").forEach(System.out::println);
        
    }
}