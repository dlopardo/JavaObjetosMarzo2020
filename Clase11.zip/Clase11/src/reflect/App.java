package reflect;

import java.lang.reflect.Field;
import stream.Persona;

public class App {
    public static void main(String[] args) {
        String texto="";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        
        // Clase StringBuilder StringBuffer;
        StringBuilder sb=new StringBuilder();
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb+"\t"+sb.hashCode());
        
        for(int a=0;a<=200000;a++){ 
            //texto+="X";
            sb.append("X");
        }
        
        
        //Api Reflect
        Persona p=new Persona("Julia","Galarza",23);
        
        System.out.println(p.getClass().getName());
        System.out.println(p.getClass().getSimpleName());
        System.out.println(p.getClass().getSuperclass().getName());
        
        Field[] campos=p.getClass().getDeclaredFields();
        for(Field f:campos) System.out.println(f.getName()+"\t"+f.getType());
        
    }
}