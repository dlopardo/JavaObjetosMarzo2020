package collections;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class App {
    public static void main(String[] args) {
        
        //Vector
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Rojo");
        autos[1]=new Auto("VW","Gol","Blanco");
        autos[2]=new Auto("Renault","Kangoo","Bordo");
        autos[3]=new Auto("Peugeot","208","Negro");
        
        //recorrido por indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        //recorrido forEach jdk 5 o sup.
        for(Auto a:autos) System.out.println(a);
        
        //Collections
        
        //Interface List
        List lista=new ArrayList();
        lista.add(new Auto("Ford","Ka","Negro"));                   // 0
        lista.add(new Auto("Citroen","Berlingo","Amarillo"));       // 1
        lista.add("hola");                                          // 2
        lista.add("chau");                                          // 3
        lista.add(22);                                              // 4
        
        //lista.remove("chau");
        
        //copiar los autos del vector autos a lista
        for(Auto a:autos) lista.add(a);
        
        System.out.println("*************************************************");
        //recorrido con indices
        //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        //recorrido forEach
        //for(Object o:lista) System.out.println(o);
        
        
        // metodo .forEach() JDK 8 o sup.
        //lista.forEach(o->System.out.println(o));
        lista.forEach(System.out::println);
        //lista.forEach(o->{
        //    System.out.println(o);
        //});
        
        
        // Uso de Generics <> JDK 5
        //List<Auto>lista2=new LinkedList();
        //List<Auto>lista2=new Vector();
        List<Auto>lista2=new ArrayList();
        lista2.add(new Auto("Citroen","C4","Negro"));
        
        Auto auto1=(Auto)lista.get(0);
        Auto auto2=lista2.get(0);
        
        //Copiar los autos de lista a lista2
        lista.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        System.out.println("****************************************************");
        lista2.forEach(System.out::println);
        System.out.println("Cantidad de autos de lista2: "+lista2.size());
        
        
        //Interface Set
        Set<String>set=null;
        
        //implementación HashSet: Es la más veloz, no garantiza el orden 
        //                          de los elementos.
        //set= new HashSet();
        
        //implementación LinkedHashSet: Almacena elementos en una lista enlazada
        //                          por orden de ingreso.
        //set=new LinkedHashSet();
        
        //implementación TreeSet: Almacena elementos en un arbol. por orden natural
        set=new TreeSet();
        
        //appSet
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Viernes");
        set.add("Martes");
        set.add("Lunes");
        set.add("Sábado");
        set.add("Domingo");
        set.add("Lunes");
        System.out.println("***********************************************");
        set.forEach(System.out::println);
        
        //setAutos
        Set<Auto>setAutos=new TreeSet();
        setAutos.add(new Auto("Citroen","C4","Blanco"));
        setAutos.add(new Auto("Citroen","C4","Azul"));
        setAutos.add(new Auto("Citroen","C3","Negro"));
        setAutos.addAll(lista2);
        
        /*
            DecimalFormat df=new DecimalFormat("000");
            Ana,012
            Ana,009
        
        */
        
        System.out.println("***********************************************");
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
        
        
        //Clase Stack Pilas LIFO Last In First Out
        Stack<Auto>pilaAuto=new Stack();
        pilaAuto.push(new Auto("Chevrolet","Corsa","Gris"));
        // .push() apila un elemento en la pila.
        pilaAuto.addAll(setAutos);
        System.out.println("***********************************************");
        pilaAuto.forEach(System.out::println);
        System.out.println("***********************************************");
        System.out.println("Longitud de pila: "+pilaAuto.size());
        while(!pilaAuto.isEmpty()){
            System.out.println(pilaAuto.pop());
            // .pop() //desapila un elemento
        }
        System.out.println("Longitud de pila: "+pilaAuto.size());
        
        //Clase ArrayDeque Colas FIFO First In First Out
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("Renault","Fluence","Gris"));
        //.offer() encola un elementos en la cola
        colaAutos.addAll(setAutos);
        System.out.println("***********************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("***********************************************");
        System.out.println("Longitud de cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
            // .poll() desencola un elemento
        }
        System.out.println("Longitud de cola: "+colaAutos.size());
        
        
        //Interface Map
        Map<String,String>mapa=null;
        
        //Implementación HashMap: es la más veloz, no garantiza el orden de los elementos
        //mapa=new HashMap();
        
        //Implementacion Hashtable: es igual a HashMap pero es obsoleta.
        //mapa=new Hashtable();
        
        //Implementación LinkedHashMap: almacena elementos en una lista enlazada por orden
        //                                  de ingreso.
        //mapa=new LinkedHashMap();
        
        //Implementación TreeMap:   Almacena elementos en un arbol, por orden natural por llave
        mapa=new TreeMap();
        
        //appMap
        mapa.put("lu", "lunes");
        mapa.put("ma", "martes");
        mapa.put("mi", "miércoles");
        mapa.put("ju", "jueves");
        mapa.put("vi", "viernes");
        mapa.put("sa", "sábado");
        mapa.put("do", "domingo");
        
        System.out.println(mapa.get("ma"));
        System.out.println("****************************************************");
        mapa.forEach((k,v)->System.out.println(k+" "+v));
        
        System.getProperties().keySet().forEach(k->System.out.println(k+" "+System.getProperty((String) k)));
        System.getenv().forEach((k,v)->System.out.println(k+" "+v));
                
        
        setAutos.add(new Auto("Hiunday","i10","Rojo"));
        
        //Api Stream JDK 8 o sup.
                       
        System.out.println("****************************************************");
        // select * from autos
        //setAutos.forEach(System.out::println);
        setAutos.stream().forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select * from autos where color='negro';
        setAutos
                .stream()
                .filter(a->a.getColor().equalsIgnoreCase("negro"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select * from autos where marca like '%u%';
        setAutos
                .stream()
                .filter(a->a.getMarca().toLowerCase().contains("u"))
                .forEach(System.out::println);
        
    }
}