package exceptions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class App {
    public static void main(String[] args) {
        //System.out.println(10/0);
        //System.out.println("Esta sentencia no se ejecuta!");
        
        /*
                Estructura try - catch - finally

                try{                                // Obligatorio
                    // - Colocar aqui las sentencias que pueden lanzar exception.
                    // - Estas sentencias tienen mayor costo de hardware.
                    // - Si puede se ejecuta correctamente y finaliza el bloque Try,
                    //      y se pasa el control al bloque Finally.
                    // - Si se produce una Exception se detiene el bloque Try y se pasa el
                    //      control de ejecución al bloque Catch.
                } catch(Exception e) {              // Obligatorio
                    // - Este bloque se ejecuta en caso de Exception.
                    // - Se recibe como parametro un objeto del tipo Exception e
                    // - Una vez terminado este bloque continua el control de ejecución en
                    //      en el bloque finally.
                } finally {                         // Opcional
                    // Este bloque se ejecuta siempre.
                    // Las variables declaradas en Try o Cacth esta fuera scope.
                }
                // El programa termina normalmente
        */
        
        try{
            System.out.println("Hola a todos");
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta.");
        }catch(Exception e){
            System.out.println("Ocurrio un error!!!");
            System.out.println(e);
        }finally{
            System.out.println("Bloque finally se ejecuta siempre!!");
        }
        System.out.println("El programa termina normalmente!");

        System.out.println("****************************************************");

            //Unchecked Exceptions
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("26x");
            //GeneradorExceptions.generar(null, 1);
        
            //Checked Exceptions
            //FileReader in=new FileReader(new File("texto.txt"));
            
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("26x");
            //GeneradorExceptions.generar(null, 1);
            //FileReader in=new FileReader(new File("texto.txt"));
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        // Captura Personalizada de Exceptions
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("22x");
            //GeneradorExceptions.generar("hola", -1);
            FileReader in=new FileReader(new File("texto.txt"));
        //} catch (ArrayIndexOutOfBoundsException e){
        //    System.out.println("Indice Fuera de Rango!");
        } catch (ArithmeticException e){
            System.out.println("División / 0");
        } catch (NumberFormatException e){
            System.out.println("Formato de numero incorrecto");
        //} catch (StringIndexOutOfBoundsException e){
        //    System.out.println("Indice Fuera de Rango!");
        //}catch(ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e){
            //Multicatch
        //    System.out.println("Indice Fuera de Rango!");
        } catch(IndexOutOfBoundsException e){
            System.out.println("Indice Fuera de Rango!");
        } catch (NullPointerException e){
            System.out.println("Puntero Nulo");
        } catch (FileNotFoundException e){
            System.out.println("Archivo no encontrado");
        } catch (IOException e){
            System.out.println("Error I/O");
        } catch (Exception e) {
            System.out.println("Ocurrio un error no esperado!");
        }
        
        
    }
}