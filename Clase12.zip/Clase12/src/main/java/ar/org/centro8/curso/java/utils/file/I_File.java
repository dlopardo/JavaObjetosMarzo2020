package ar.org.centro8.curso.java.utils.file;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_File {
    default void print(){
        System.out.println(getText());
    }
    String getText();
    void setText(String text);
    void appendText(String text);
    default void clear(){
        setText("");
    }
    default void addLine(String line){
        appendText(line+"\n");
    }
    default void addLines(List<String>lines){
        lines.forEach(this::addLine);
    }
    List<String>getAll();
    default List<String>getLikeFilter(String filter){
        // Código Java jdk7 o inferior.
        //List<String>list=new ArrayList();
        //if(filter==null) return list;
        //for(String st:getAll()){
        //    if(st.toLowerCase().contains(filter.toLowerCase())){
        //        list.add(st);
        //    }
        //}
        //return list;
        
        // Código API Stream JDK 8 o sup.
        if(filter==null) return new ArrayList<String>();
        return getAll()
                .stream()
                .filter(st->st.toLowerCase().contains(filter.toLowerCase()))
                .collect(Collectors.toList());
    }
}