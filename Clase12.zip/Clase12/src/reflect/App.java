package reflect;

import collections.Auto;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import stream.Persona;

public class App {
    public static void main(String[] args) throws Exception{
        String texto="";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        
        // Clase StringBuilder StringBuffer;
        StringBuilder sb=new StringBuilder();
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb+"\t"+sb.hashCode());
        
        for(int a=0;a<=200000;a++){ 
            //texto+="X";
            sb.append("X");
        }
        
        
        //Api Reflect
        Persona p=new Persona("Julia","Galarza",23);
        
        System.out.println(p.getClass().getName());
        System.out.println(p.getClass().getSimpleName());
        System.out.println(p.getClass().getSuperclass().getName());
        System.out.println("**********************************************");
        Field[] campos=p.getClass().getDeclaredFields();
        for(Field f:campos) System.out.println(f.getName()+"\t"+f.getType());
        System.out.println("**********************************************");
        campos=p.getClass().getFields();
        for(Field f:campos) System.out.println(f.getName()+"\t"+f.getType());
        System.out.println("**********************************************");
        Method[] metodos=p.getClass().getDeclaredMethods();
        for(Method m:metodos) System.out.println(m.getName()+"\t"+m.getReturnType());
        System.out.println("**********************************************");
        metodos=p.getClass().getMethods();
        for(Method m:metodos) System.out.println(m.getName()+"\t"+m.getReturnType());
        System.out.println("**********************************************");
        Constructor[] constructores=p.getClass().getDeclaredConstructors();
        for(Constructor c:constructores){
            System.out.println(c.getName());
            for(Parameter pa: c.getParameters()) System.out.println(pa.getName()+"\t"+pa.getType());
            System.out.println("------------");
        }
        
        Auto a=new Auto("Ford","Fiesta","Rojo");
        
        //crear un objeto de la misma clase que p
        //Object o=p.getClass().newInstance();
        //Object o=p.getClass().getConstructors()[0].newInstance();
        Object o=p.getClass().getConstructor().newInstance();
        
        //en nuevo objeto fijar como estado de todos los atributos String el valor X
        for(Method m:o.getClass().getDeclaredMethods()){
            if(m.getName().startsWith("set") 
                    && m.getParameters().length==1 
                    && m.getParameters()[0].getType().getSimpleName().equals("String")){
                //System.out.println(m.getName());
                m.invoke(o, "X");
            }
        }
        System.out.println(o);
        
    }
}