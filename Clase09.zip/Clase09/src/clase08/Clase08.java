package clase08;

import java.util.Scanner;

public class Clase08 {

    public static void main(String... args) {
        
        //Clase Object
        
        Object o="hola";
        
        //inner class
        class Dato{
            int dato;

            public Dato(int dato) {
                this.dato = dato;
            }

            @Override
            public String toString() {
                return "Dato{" + "dato=" + dato + '}';
            }

            @Override
            public int hashCode() {
                return toString().hashCode();
            }

            @Override
            public boolean equals(Object obj) {
                if(obj==null || !(obj instanceof Dato)) return false;
                return hashCode()==obj.hashCode();
            }

        }
        
        /*
        Dato d1=new Dato(2);
        Dato d2=d1;
        Dato d3=new Dato(d1.dato);
        Dato d4=new Dato(4);
        String d5="2";
        String d6=new String("2");
        
        System.out.println("d1.hashCode(): "+d1.hashCode());
        System.out.println("d2.hashCode(): "+d2.hashCode());
        System.out.println("d3.hashCode(): "+d3.hashCode());
        System.out.println("d4.hashCode(): "+d4.hashCode());
        System.out.println("d5.hashCode(): "+d5.hashCode());
        System.out.println("d6.hashCode(): "+d6.hashCode());
        
        System.out.println("d1.equals(d1):"+d1.equals(d1));
        System.out.println("d1.equals(d2):"+d1.equals(d2));
        System.out.println("d1.equals(d3):"+d1.equals(d3));
        System.out.println("d1.equals(d4):"+d1.equals(d4));
        System.out.println("d1.equals(d5):"+d1.equals(d5));
        System.out.println("d5.equals(d6):"+d5.equals(d6));

        */    
        
        //        Clase System
        // System representa el entorno de ejecución. 
                
        //Atributo out: proporciona un stream de salida sincronizado.
        //Atributo err: proporciona un stream de salida no sincronizado.
        //Atributo in:  proporciona un stream de entrada sincronizado. 
        /*
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        System.out.println("Hola 21");
        System.out.println("Hola 22");
        System.out.println("Hola 23");
        System.out.println("Hola 24");
        System.out.println("Hola 25");
        System.out.println("Hola 26");
        System.out.println("Hola 27");
        System.out.println("Hola 28");
        System.out.println("Hola 29");
        System.out.println("Hola 30");
        
        System.err.println("Ocurrio un error!");
        */
        //System.out.println("Ingrese su nombre: ");
        //String nombre=new Scanner(System.in).nextLine();
        
        
        //método .getProperties();
        //System.out.println(System.getProperties());
        
        //método .getProperty();
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("user.language"));
        System.out.println(System.getProperty("user.country"));
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.dir"));
        System.out.println(System.getProperty("user.home"));
        
        //método .getEnv();
        //System.out.println(System.getenv());
        System.out.println("*******************************************");
        System.out.println(System.getenv("USER"));
        System.out.println("*******************************************");
        
        //Runtime
        System.out.println(Runtime.version());
        System.out.println(Runtime.getRuntime().availableProcessors());
        
        //Clase String
        String cadena="Esto es una cadena de texto!";
        String cadena2="hola";
        
        //metodo .contains()
        System.out.println(cadena.contains("una"));
        System.out.println(cadena.contains("hola"));
        
        //metodo .startsWith() .endsWith()
        System.out.println(cadena.startsWith("Esto"));
        System.out.println(cadena.startsWith("hola"));
        System.out.println(cadena.endsWith("!"));
        System.out.println(cadena.endsWith("?"));
        
        //.trim()
        System.out.println("  hola chau   ".trim());
        
        //.indexOf()
        System.out.println(cadena.indexOf("x"));
        
        //.length()
        System.out.println(cadena.length());
        
        //.subString()
        System.out.println(cadena.substring(5));
        System.out.println(cadena.substring(5,10));
        
        //.charAt()
        System.out.println(cadena.charAt(6));
        
        //.equals() .equalsIgnoreCase()
        System.out.println(cadena2.equals("hola"));
        System.out.println(cadena2.equals("Hola"));
        System.out.println(cadena2.equalsIgnoreCase("HOLA"));
        
        //.toLowerCase() .toUpperCase()
        System.out.println(cadena.toLowerCase());
        System.out.println(cadena.toUpperCase());
        
        //.split()
        String[] vector = cadena.split(" ");
        for(int a=0;a<vector.length; a++) System.out.println(vector[a]);
        
        String config=System.getProperties().toString();
        vector=config.split(",");
        for(int a=0;a<vector.length; a++) System.out.println(vector[a]);
        
        //String.format();        
        String texto="Hola %s, su edad es %d";
        System.out.println(String.format(texto, "Carlos",48));
        
        //varargs JDK 5 o sup.
        String[] semana={"Lunes","Martes","Miércoles","Jueves","Viernes"};
        recorrer2("primavera","verano","otoño","invierno");
    }
    
    public static void recorrer(String[] vector){
        for(int a=0;a<vector.length;a++) System.out.println(vector[a]);
    }
    
    public static void recorrer2(String... vector){
        for(int a=0;a<vector.length;a++) System.out.println(vector[a]);
    }
    
    public static void unir(String texto, String texto2){
        System.out.println(texto+" "+texto2);
    }
    
    public static void saludar(){
        System.out.println("Hola soy una persona!");
    }

}












