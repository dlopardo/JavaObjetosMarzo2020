package collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class App {
    public static void main(String[] args) {
        
        //Vector
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Rojo");
        autos[1]=new Auto("VW","Gol","Blanco");
        autos[2]=new Auto("Renault","Kangoo","Bordo");
        autos[3]=new Auto("Peugeot","208","Negro");
        
        //recorrido por indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        //recorrido forEach jdk 5 o sup.
        for(Auto a:autos) System.out.println(a);
        
        //Collections
        
        //Interface List
        List lista=new ArrayList();
        lista.add(new Auto("Ford","Ka","Negro"));                   // 0
        lista.add(new Auto("Citroen","Berlingo","Amarillo"));       // 1
        lista.add("hola");                                          // 2
        lista.add("chau");                                          // 3
        lista.add(22);                                              // 4
        
        //lista.remove("chau");
        
        //copiar los autos del vector autos a lista
        for(Auto a:autos) lista.add(a);
        
        System.out.println("*************************************************");
        //recorrido con indices
        //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        //recorrido forEach
        //for(Object o:lista) System.out.println(o);
        
        
        // metodo .forEach() JDK 8 o sup.
        //lista.forEach(o->System.out.println(o));
        lista.forEach(System.out::println);
        //lista.forEach(o->{
        //    System.out.println(o);
        //});
        
        
        // Uso de Generics <> JDK 5
        //List<Auto>lista2=new LinkedList();
        //List<Auto>lista2=new Vector();
        List<Auto>lista2=new ArrayList();
        lista2.add(new Auto("Citroen","C4","Negro"));
        
        Auto auto1=(Auto)lista.get(0);
        Auto auto2=lista2.get(0);
        
        //Copiar los autos de lista a lista2
        lista.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        System.out.println("****************************************************");
        lista2.forEach(System.out::println);
        System.out.println("Cantidad de autos de lista2: "+lista2.size());
        
        
    }
}