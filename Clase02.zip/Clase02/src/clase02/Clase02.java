package clase02;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Clase02 {
    public static void main(String[] args) {
        
        // Tipo de datos enteros			1 byte
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);

        /*
                1
                --------
        */ 

        // Tipo de datos byte signed		1 byte
        byte by=-100;
        by=120;
        System.out.println(by);		

        /*
         * 
         * 			tinyint
         * 
         * 		|-------|-------|
         *    -128      0 	   127
         * 
         * 
         * 
         * 			tinyint unsigned
         * 			byteU
         * 
         * 		|---------------|
         * 		0			   255
         * 
         */ 

        // Tipo de datos short			2 byte
        short sh=32000;
        System.out.println(sh);

        // Tipo de datos int			4 bytes
        int in=2000000000;
        System.out.println(in);
	
        // Tipo de datos long                   8 bytes
        long lo=3000000000L;
        System.out.println(lo);
        
        // Tipo de char (unsigned) (unicode)    2 bytes
        char ch=65;
        ch+=32;
        ch='f';
        System.out.println(ch);
        
        // Tipo de datos Punto Flotante
        
        // Tipo de datos float 32 bits
        float fl=3.45f;
        System.out.println(fl);
                
        // Tipo de datos double 64 bits
        double dl=3.45;
        System.out.println(dl);
        
        fl=10;
        dl=10;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        fl=100;
        dl=100;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        // Clase String
        String st="Hola";
        System.out.println(st);
        
        //System.out.println(st.value[2]);
        System.out.println(st.charAt(2));
        
        /*
        
            String st="Hola";
        
                Hasta JDK 9         private final char[] value; // 8 bytes          
        
                JDK 10 o sup.       private final byte[] value; // 4 bytes
        
        */
        
        // = operador de asignación
        int nro;
        nro = 2;
        // <--
        
        int nro1 = 7;
        int nro2 = 5;
        
        nro2 = nro1;
        //  <--
        System.out.println(nro2);           // 7
        
        // Tipo de datos var            JDK 9 0 sup.
        var var1=3;                     //int
        //var1="Hola";                  //error
        var1=2;
        var var2=2L;                    //long
        var var3='a';                   //char
        var var4="a";                   //String
        var var5=true;                  //boolean
        var var6=3.45;                  //double
        var var7=3.45d;                 //double
        var var8=3.45f;                 //float
        
        
        //Clase DecimalFormat
        double precio=2000000.50;
        System.out.println(precio);
        DecimalFormat df=new DecimalFormat("###,###,###.00");
        System.out.println(df.format(precio));
        
        //Clase  BigDecimal
        BigDecimal bg=new BigDecimal("000000000000000");
                
        // Uso de literales
        metodo(false);
        
        //Arquitectura de proyecto
        JOptionPane.showMessageDialog(null, "Hola a todos!!");
        
        
        
        
        
        
        
        
    }
    public static void metodo(int x){
        System.out.println("int");
    }
    public static void metodo(boolean x){
        System.out.println("boolean");
    }
    public static void metodo(char x){
        System.out.println("char");
    }
    public static void metodo(long x){
        System.out.println("long");
    }
    public static void metodo(String x){
        System.out.println("String");
    }
    public static void metodo(float x){
        System.out.println("float");
    }
    public static void metodo(double x){
        System.out.println("double");
    }
}