package ar.org.centro8.curso.java.clase33;

public class Saludo {
    public synchronized void saludar(String nombre, boolean esJefe){
        try {        
            if(esJefe){
                System.out.println("Jefe: Holaaa Llegue!!!");
                
                notify();
                Thread.sleep(200);
                
                notify();
                Thread.sleep(200);
                
                notify();
                Thread.sleep(200);
                
                notify();
                Thread.sleep(200);
                
                notifyAll();
            }else{
                System.out.println("Llego "+nombre);
                wait();
                System.out.println(nombre+": Hola Jefe!");
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
