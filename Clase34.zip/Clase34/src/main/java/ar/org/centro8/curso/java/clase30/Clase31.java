package ar.org.centro8.curso.java.clase30;
public class Clase31 {
    public static void main(String[] args) {
        /*
            Ciclo de vida de un Thread
        
        NEW             RUNNABLE    BLOCKED             WAITING     TERMINATED
        
        new Thread()    .start()    blockeo por I/O     .sleep()    muerte natural
                                                        .wait()     asesinato   .stop()
        */
        
        Thread t1=new Thread(new HiloR("hilo1"));
        Thread t2=new Thread(new HiloR("hilo2",800));
        Thread t3=new Thread(new HiloR("hilo3",600));
        Thread t4=new Thread(new HiloR("hilo4",400));
        
        System.out.println(t1.getState());
        
        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.NORM_PRIORITY);
        t3.setPriority(Thread.NORM_PRIORITY);
        t4.setPriority(Thread.MAX_PRIORITY);
        
        /*
            JVM         Windows         Linux           Mac
        
            1               1           -10             1
            2               20          -80             10
            3
            4
            5               50          0               25
            6
            7
            8
            9
            10              100         10              50
        
        */
        
        
        //t1.start();
        //t2.start();
        //t3.start();
        //t4.start();
        //t1.start();
        
        System.out.println(t1.getState());
        
        // método .join()
        try {
            t1.start();
            //t1.join();
            t2.start();
            //t2.join();
            t3.start();
            //t3.join();
            t4.start();
            //t4.join();
            
            t1.join();
            t2.join();
            t3.join();
            t4.join();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        // método .yield()
        
        //Synchronized
        
        
        //try {Thread.sleep(11000);} catch(Exception e){}
        
        System.out.println("-- Fin del programa --");
        System.out.println(t1.getState());
    }
}
