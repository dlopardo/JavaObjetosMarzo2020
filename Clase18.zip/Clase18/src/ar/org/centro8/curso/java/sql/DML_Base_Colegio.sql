-- DML Data Manipulation Language

insert into cursos (titulo,profesor,dia,turno) values
('','','',''),
('','','',''),
('','','',''),
('','','',''),
('','','','');
