package ar.org.centro8.curso.java.clase30;

public class HiloT extends Thread {
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {
        //Este método puede ejecutarse en un nuevo hilo.
        
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try { Thread.sleep(1000); } catch(Exception e){}
        }
        
    }
    
}
