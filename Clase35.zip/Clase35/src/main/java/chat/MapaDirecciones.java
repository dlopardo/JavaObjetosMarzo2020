package chat;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapaDirecciones {
    public static  Map<String,String>getMapa(){
        Map<String,String>map=new LinkedHashMap();
        map.put("Carlos",   "127.0.0.1");
        map.put("Patricio", "192.168.0.3");
        map.put("Ana",      "127.0.0.1");
        map.put("Manuel",   "127.0.0.1");
        return map;
    }
}
