package serializado;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Serializable {
    public static void main(String[] args) {
        String file="personas.dat";
        
        //Serialización
        try (ObjectOutputStream out=new ObjectOutputStream(
                new FileOutputStream(file))) {
            out.writeObject(new Persona("Laura","Perez",34));
            out.writeObject(new Persona("Mario","Tolo",35));
            out.writeObject(new Persona("Diego","Vargas",31));
            out.writeObject(new Persona("Monica","Perez",24));
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Deserialización
        try (ObjectInputStream in=new ObjectInputStream(
                    new FileInputStream(file))){
            while(true){
                Persona p=(Persona)in.readObject();
                System.out.println(p);
            }
        } catch (EOFException e) { System.out.println("-- Fin del archivo --"); 
        } catch (Exception e) {
            System.out.println("");
        }
        
    }
}
