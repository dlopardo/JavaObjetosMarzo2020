package serializado;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSerializado {
    public static void main(String[] args) {
        try (ServerSocket ss=new ServerSocket(7000)){
            while(true){
                System.out.println("Esperando conexión de cliente......");
                try (
                        Socket so=ss.accept();
                        ObjectInputStream in=new ObjectInputStream(
                                so.getInputStream());
                        ObjectOutputStream out=new ObjectOutputStream(
                                so.getOutputStream());
                ){
                    try{
                        Persona p=(Persona)in.readObject();
                        System.out.println(p);
                        out.writeUTF("Se recibio un Objeto de Persona. OK!");
                    }catch(ClassCastException e){
                        out.writeUTF("No se recibio un Objeto de Persona. OK!");
                    }catch(Exception e){
                        out.writeUTF("No se recibio el Objeto!");
                        System.out.println(e);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}