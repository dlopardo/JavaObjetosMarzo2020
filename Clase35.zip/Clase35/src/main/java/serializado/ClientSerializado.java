package serializado;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientSerializado {
    public static void main(String[] args) {
        Persona p=new Persona("Carlos","Ríos",48);
        try (Socket so=new Socket("localhost",7000);
                ObjectOutputStream out=new ObjectOutputStream(
                                so.getOutputStream());
                ObjectInputStream in=new ObjectInputStream(
                                so.getInputStream());
        ){
            out.writeObject(p);
            System.out.println(in.readUTF());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
