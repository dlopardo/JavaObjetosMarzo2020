package ar.org.centro8.curso.java.clase32;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class App {
    public static void main(String[] args) {
        Cuenta cuenta = new Cuenta();
        
        ClienteT c1=new ClienteT("Ana",cuenta);
        ClienteT c2=new ClienteT("Luis",cuenta);
        
        new Thread(c1).start();
        new Thread(c2).start();

        /*
            Que diferencia hay entre Hashtable y HashMap?
        
        Hashtable:
            - todos sus métodos son totalmente sincronizados.
            - es safe thread.
            - es lenta.
            - es obsoleta.
        
        HashMap:
            - todos sus métodos no estan sincronizades.
            - no es safe thread.
            - es veloz.
        
        Clase Collections JDK 7.0 o sup.
            - provee un factory de colleciones parcialmente sincronizadas
        
        */
        
        //Hashtable<String,String> map=new Hashtable();
        //HashMap<String,String> map=new HashMap();
        Map<String,String> map=Collections.synchronizedMap(new HashMap<String,String>());
        
        map.put("lu", "lunes");
        map.put("ma", "martes");
        map.put("mi", "miércoles");
        map.put("ju", "jueves");
        map.put("vi", "viernes");
        map.put("sa", "sábado");
        map.put("do", "domingo");
        System.out.println(map.get("lu"));
        map.forEach((k,v)->System.out.println(k+" "+v));
        
        
        
        //Queda pendiente Saludo al jefe!
        
        
    }
}
