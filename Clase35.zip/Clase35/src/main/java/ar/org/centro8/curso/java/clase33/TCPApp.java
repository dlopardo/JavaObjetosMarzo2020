package ar.org.centro8.curso.java.clase33;
public class TCPApp {
    public static void main(String[] args) {
        /*
            Protocolo TCP:  Caro    Lento    Exacto
            Protocolo UDP:  Barato  Veloz   No Exacto
        
            
                    Protocolo TCP / IP
        
            Server                              Client
            -----------                         -----------
            new ServerSocket(int port);         new Socket(String ip, int port);
            .accept()
            -----------                         -----------
            OutputStream        -------->       InputStream
            InputStream         <--------       OutputStream
            -----------                         -----------
            .close()                            .close()
        
            BufferedInputStream - BufferedOutputStream: Stream de buffers.
            DataInputStream - DataOutpuStream:  primitivos de java.
            ObjectOutputStream - ObjectInputStream: Objetos de Java
            
        */
    }
}
