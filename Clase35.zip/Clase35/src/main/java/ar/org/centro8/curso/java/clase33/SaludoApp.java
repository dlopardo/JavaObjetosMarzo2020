
package ar.org.centro8.curso.java.clase33;

import java.util.Iterator;
import java.util.List;

public class SaludoApp {
    public static void main(String[] args) {
        //Uso De Iterator
        List<String>list=List.of("Lunes","Martes","Miércoles","Jueves","Viernes");
        Iterator it=list.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
        for(String st:list) System.out.println(st);
        
        Saludo saludo=new Saludo();
        
        Empleado ana=new Empleado("ana", false, saludo);
        Empleado luis=new Empleado("luis", false, saludo);
        Empleado ivo=new Empleado("ivo", false, saludo);
        Empleado maria=new Empleado("maria", false, saludo);
        Empleado jefe=new Empleado("jefe", true, saludo);
        
        new Thread(ana).start();
        new Thread(luis).start();
        new Thread(ivo).start();
        new Thread(maria).start();
        try { Thread.sleep(200); } catch(Exception e){}
        new Thread(jefe).start();
        
        
    }
}
