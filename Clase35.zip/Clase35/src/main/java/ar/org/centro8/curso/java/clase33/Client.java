package ar.org.centro8.curso.java.clase33;

import java.io.InputStream;
import java.net.Socket;

public class Client {
    public static void main(String[] args) {
        int car;
        try (
                Socket so=new Socket("localhost",8000);
                InputStream in=so.getInputStream();
        ){
            while((car=in.read())!=-1){
                System.out.print((char)car);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
