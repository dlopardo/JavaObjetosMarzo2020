package Parte16.ar.org.centro8.curso.java.utils.files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public interface I_File {
    default void print(){ //los metodos default tienen codigo
        System.out.println(getText());
    }
    String getText(); 
    void setText(String text); //Renueva texto
    void appendText(String text); //Agrega texto
    default void clear(){
        setText("");
    }
    default void addLine(String line){ //ingresa una linea
        appendText(line+"\n"); //agrego una linea agregando nuevo texto llamando
                              //appendText
    }
    default void addLines(List<String>lines){ //Se agrega una coleccion con varias lineas
        lines.forEach(this::addLine); //recorro y agrego lineas con addLine         
    }
    List<String>getAll();//devuelve la lista total de lineas
    default List<String>getLikeFilter(String filter){ //ingresa un filtro que devuelve el listado de linea
                                                     //que cumple con este filtro
        if(filter==null) return new ArrayList();
        return getAll()
                .stream()
                //Se filtra lo que queramos y devuelve un list String
                .filter(st->st.toLowerCase().contains(filter.toLowerCase())) 
                .collect(Collectors.toList()); //Este metodo permite transformar
                                               //El string en varios metodos de recorrido
    }
    default LinkedHashSet<String>getLinkedHashSet(){ //metodo que devuelve LinkedHashSet
        LinkedHashSet<String> set=new LinkedHashSet(); //recomendado para mostrar varios valores duplicados
        set.addAll(getAll());
        return set;
    }
    default TreeSet<String>getTreeSet(){ //Este metodo devuelve un TreeSet
        TreeSet<String> set=new TreeSet(); //imlementa las mismas lineas de codigo que HashSet
        set.addAll(getAll());
        return set;
    }
    default List<String>getSortedLines(){ //Devuelve una lista en orden natural
        return getAll()
                .stream()
                .sorted()
                .collect(Collectors.toList());
    }
    default List<String>getReversedSortedLines(){ //Devuelve una lista ordenado al reves
        return getAll()
                .stream()
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
    }
    default void remove(String line){ //Ingresa una linea y la remueve
        List<String>list=getAll();
        list.remove(line);
        clear();
        addLines(list);
    }
}