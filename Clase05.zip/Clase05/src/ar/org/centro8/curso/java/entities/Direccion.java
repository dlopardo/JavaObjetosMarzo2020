package ar.org.centro8.curso.java.entities;

public class Direccion {
    String calle;
    int nro;
    String piso;
    String depto;
    String ciudad;
}