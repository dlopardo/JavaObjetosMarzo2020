package ar.org.centro8.curso.java.clase33;

import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) {
        String mensaje = "Servidor de Carlos";
        try (ServerSocket ss=new ServerSocket(8000)){
            while(true){
                System.out.println("Esperando conexión de cliente....");
                try(
                        Socket so=ss.accept();
                        OutputStream out=so.getOutputStream();
                ) {
                    System.out.println("Se conecto: "+so.getInetAddress());
                    out.write(mensaje.getBytes());
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
