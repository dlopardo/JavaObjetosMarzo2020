package ar.org.centro8.curso.java.clase30;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class ReproductorR implements Runnable {
    public static void main(String[] args){
        try {
            try {
                new Player(new FileInputStream(new File("res/soledad.mp3"))).play();
            } catch (JavaLayerException ex) {
                System.out.println("javaLayerException");
                System.out.println(ex);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException");
            System.out.println(ex);
        }
    }

    @Override
    public void run() {
        try {
            new Player(new FileInputStream(new File("res/soledad.mp3"))).play();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
