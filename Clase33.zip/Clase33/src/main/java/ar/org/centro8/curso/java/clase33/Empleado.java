package ar.org.centro8.curso.java.clase33;
public class Empleado implements Runnable{
    String nombre;
    boolean esJefe;
    Saludo saludo;

    public Empleado(String nombre, boolean esJefe, Saludo saludo) {
        this.nombre = nombre;
        this.esJefe = esJefe;
        this.saludo = saludo;
    }

    @Override
    public void run() {
        saludo.saludar(nombre, esJefe);
    }
            
}
