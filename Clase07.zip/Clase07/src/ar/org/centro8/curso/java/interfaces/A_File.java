package ar.org.centro8.curso.java.interfaces;

import java.io.File;

public abstract class A_File {
    
    private File file;

    public A_File(File file) {
        this.file = file;
    }

    /**
     * La javaDoc es heredada.
     * @param text 
    */
    public abstract void setText(String text);
    public abstract String getText();
    public void info(){
        System.out.println("Clase Abstract A_File");
    }
}