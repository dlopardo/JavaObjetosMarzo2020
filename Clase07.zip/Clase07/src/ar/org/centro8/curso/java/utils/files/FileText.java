package ar.org.centro8.curso.java.utils.files;

import ar.org.centro8.curso.java.interfaces.I_File;

public class FileText implements I_File{

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo archivo de texto!!");
    }

    @Override
    public String getText() {
        return "Leyendo Archivo de texto!!";
    }

}