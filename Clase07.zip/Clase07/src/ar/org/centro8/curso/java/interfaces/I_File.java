package ar.org.centro8.curso.java.interfaces;

public interface I_File {
    /*
    Que es una interface:
        - Todos sus miembros son publicos.
        - No puede tener atributos ni constructores.
        - Si puede tener atributos constantes o static
        - Todos sus métodos son abstractos.
        - Una clase puede implementar todas las interfaces que necesite.
    */
    
    /**
     * La javaDoc es heredada.
     * @param text 
     */
    void setText(String text);
    String getText();
    
    //Interfaces en Java 8, Métodos default.
    default void info(){
        System.out.println("Interface I_File");
    }
    
}