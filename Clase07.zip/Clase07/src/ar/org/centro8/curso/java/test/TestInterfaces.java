package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.interfaces.I_File;
import ar.org.centro8.curso.java.utils.files.FileBinary;
import ar.org.centro8.curso.java.utils.files.FileCloud;
import ar.org.centro8.curso.java.utils.files.FileText;
import java.util.Scanner;

public class TestInterfaces {
    public static void main(String[] args) throws Exception {
        //TestInterfaces
        
        I_File file=null;
        
        //file=new FileBinary();
        //file=new FileCloud();
        //file=new FileText();
        
        System.out.println("Escriba 'FileText' o 'FileBinary' o 'FileCloud': ");
        String input=new Scanner(System.in).next();
        
        //if(input.equalsIgnoreCase("FileText"))      file=new FileText();
        //if(input.equalsIgnoreCase("FileCloud"))     file=new FileCloud();
        //if(input.equalsIgnoreCase("FileBinary"))    file=new FileBinary();
        
        //file=(I_File)Class
        //        .forName("ar.org.centro8.curso.java.utils.files."+input)
        //        .newInstance();
        
        file=(I_File)Class
                .forName("ar.org.centro8.curso.java.utils.files."+input)
                .getConstructor()
                .newInstance();
        
        //app
        file.setText("hola");
        System.out.println(file.getText());
        file.info();
        
  
        
        
    }
}