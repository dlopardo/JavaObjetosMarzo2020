package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        System.out.println("-- auto1 --");
        Auto auto1=new Auto("Peugeot","3008","Gris");
        Auto.acelerar();
        auto1.acelerar();
        System.out.println(auto1);
        System.out.println(auto1.getVelocidad());
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto("WV","UP","Blanco");
        auto2.acelerar();
        System.out.println(auto2);
        System.out.println(auto2.getVelocidad());
        System.out.println(auto1);
        System.out.println(auto1.getVelocidad());
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Citroen","c5","Bordo");
        System.out.println(auto3);
        System.out.println(auto3.getVelocidad());
        
    }
}